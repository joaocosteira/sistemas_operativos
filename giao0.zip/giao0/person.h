
/*
	Estrutra que caracteriza uma pessoa -> string nome e tem uma idade
*/
typedef struct Person{
	char * name;
	int age;
} Person;


// Api sobre este tipo tipo



Person new_person(char* name,int age); //construtor de pessoa

Person clone_person(Person* p);	//clona uma pessoa

void distroy_person(Person* p);	// destroy uma pessoa

int person_age(Person* p);	//dá a idade de uma pessoa

void person_change_age(Person* p,int age);	//altera a idade de uma pessoa





