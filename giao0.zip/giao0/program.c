#include<stdio.h>
#include<stdlib.h>
#include <strings.h>
#include "person.h"

int main(int argc, char const *argv[])
{
	//cria uma pessoa
	Person andre = new_person("André",20);
	printf("Idade do André é %d\n",andre.age);


	//altera a idade
	person_change_age(&andre,30);
	printf("Idade modificada do andre %d\n",andre.age);

	//cria um clone e altera a idade do clone
	Person new_andre = clone_person(&andre);
	person_change_age(&new_andre,40);

	//imprime a idade dos 2
	printf("Idade do andre %d\n",andre.age);
	printf("Idade do new andre %d\n",new_andre.age);

	//distroy os 2
	distroy_person(&new_andre);
	distroy_person(&andre);

	return 0;
}

